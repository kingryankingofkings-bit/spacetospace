# The Molten Forge Nexus Swarmers Variant Pack

Pack number: 092

Region: 06 Geothermal Abyss
Sub-location: 01 The Molten Forge
Theme: geothermal
Element variant: magma

## Contents

- 5 real low-poly `.glb` mesh assets
- 8 procedural `.png` texture/material files
- 3 placeholder `.wav` audio cues, including local music
- metadata, prefab handoff, spawn/object plans, material manifests, and audio cue manifests

## Source context used

- uploaded Geographic Master Guide image
- geographic master guide detailed maps
- basic area map manifest
- shop coverage CSV
- Dawnforge itemization pack
- Dawnforge customization pack
- special event pack

## Production note

These are browser-game source/prototype assets. They are intentionally engine-ready in organization but still need Antigravity 2.0 or your game pipeline to finalize prefabs, scripts, rigging, animations, materials, shaders, pooling, and audio replacement.
