# Special Event Encounter Bundle 16

Pack number: **182**

## GLB Assets
- `glb_assets/01_event_arena_anchor.glb` — Event Arena Anchor — static_world_anchor
- `glb_assets/02_event_elite_variant.glb` — Event Elite Variant — creature_variant_base
- `glb_assets/03_event_trigger_node.glb` — Event Trigger Node — quest_or_system_interactable
- `glb_assets/04_event_hazard_cluster.glb` — Event Hazard Cluster — static_prop_or_debris
- `glb_assets/05_event_sky_or_hazard_field.glb` — Event Sky Or Hazard Field — environment_surface_or_sky_proxy

## Textures
- `textures/01_special_event_encounter_bundle_16_albedo.png` — local surface albedo
- `textures/02_special_event_encounter_bundle_16_normal_proxy.png` — placeholder normal-map proxy
- `textures/03_special_event_encounter_bundle_16_trim.png` — architecture/prop trim sheet
- `textures/04_special_event_encounter_bundle_16_emission.png` — glowing signage, runes, creatures, UI, and VFX
- `textures/05_special_event_encounter_bundle_16_decal.png` — floor/wall decals and quest markers
- `textures/06_special_event_encounter_bundle_16_water.png` — water/liquid/caustic surface
- `textures/07_special_event_encounter_bundle_16_starfield.png` — skybox/starfield/cosmic overlay
- `textures/08_special_event_encounter_bundle_16_surface.png` — secondary local surface variation

## Audio
- `audio/special_event_encounter_bundle_16_music_loop.wav` — music — industrial-sub
- `audio/special_event_encounter_bundle_16_ambience_loop.wav` — ambience — industrial-sub
- `audio/special_event_encounter_bundle_16_event_or_pickup_sting.wav` — sting — industrial-sub