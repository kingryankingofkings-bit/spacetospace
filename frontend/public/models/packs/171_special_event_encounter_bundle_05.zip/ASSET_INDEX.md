# Special Event Encounter Bundle 05

Pack number: **171**

## GLB Assets
- `glb_assets/01_event_arena_anchor.glb` — Event Arena Anchor — static_world_anchor
- `glb_assets/02_event_elite_variant.glb` — Event Elite Variant — creature_variant_base
- `glb_assets/03_event_trigger_node.glb` — Event Trigger Node — quest_or_system_interactable
- `glb_assets/04_event_hazard_cluster.glb` — Event Hazard Cluster — static_prop_or_debris
- `glb_assets/05_event_sky_or_hazard_field.glb` — Event Sky Or Hazard Field — environment_surface_or_sky_proxy

## Textures
- `textures/01_special_event_encounter_bundle_05_albedo.png` — local surface albedo
- `textures/02_special_event_encounter_bundle_05_normal_proxy.png` — placeholder normal-map proxy
- `textures/03_special_event_encounter_bundle_05_trim.png` — architecture/prop trim sheet
- `textures/04_special_event_encounter_bundle_05_emission.png` — glowing signage, runes, creatures, UI, and VFX
- `textures/05_special_event_encounter_bundle_05_decal.png` — floor/wall decals and quest markers
- `textures/06_special_event_encounter_bundle_05_water.png` — water/liquid/caustic surface
- `textures/07_special_event_encounter_bundle_05_starfield.png` — skybox/starfield/cosmic overlay
- `textures/08_special_event_encounter_bundle_05_surface.png` — secondary local surface variation

## Audio
- `audio/special_event_encounter_bundle_05_music_loop.wav` — music — neon
- `audio/special_event_encounter_bundle_05_ambience_loop.wav` — ambience — neon
- `audio/special_event_encounter_bundle_05_event_or_pickup_sting.wav` — sting — neon