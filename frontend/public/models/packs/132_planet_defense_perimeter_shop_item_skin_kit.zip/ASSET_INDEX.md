# Planet Defense Perimeter Shop Item Skin Kit

Pack number: **132**

## GLB Assets
- `glb_assets/01_vendor_counter_terminal.glb` — Vendor Counter Terminal — quest_or_system_interactable
- `glb_assets/02_display_prop_cluster.glb` — Display Prop Cluster — static_prop_or_debris
- `glb_assets/03_shop_front_anchor.glb` — Shop Front Anchor — static_world_anchor
- `glb_assets/04_shop_guard_or_vendor_variant.glb` — Shop Guard Or Vendor Variant — creature_variant_base
- `glb_assets/05_dye_liquid_or_reflection_pool.glb` — Dye Liquid Or Reflection Pool — environment_surface_or_sky_proxy

## Textures
- `textures/01_planet_defense_perimeter_shop_item_skin_kit_albedo.png` — local surface albedo
- `textures/02_planet_defense_perimeter_shop_item_skin_kit_normal_proxy.png` — placeholder normal-map proxy
- `textures/03_planet_defense_perimeter_shop_item_skin_kit_trim.png` — architecture/prop trim sheet
- `textures/04_planet_defense_perimeter_shop_item_skin_kit_emission.png` — glowing signage, runes, creatures, UI, and VFX
- `textures/05_planet_defense_perimeter_shop_item_skin_kit_decal.png` — floor/wall decals and quest markers
- `textures/06_planet_defense_perimeter_shop_item_skin_kit_water.png` — water/liquid/caustic surface
- `textures/07_planet_defense_perimeter_shop_item_skin_kit_starfield.png` — skybox/starfield/cosmic overlay
- `textures/08_planet_defense_perimeter_shop_item_skin_kit_surface.png` — secondary local surface variation

## Audio
- `audio/planet_defense_perimeter_shop_item_skin_kit_music_loop.wav` — music — cosmic-minor
- `audio/planet_defense_perimeter_shop_item_skin_kit_ambience_loop.wav` — ambience — cosmic-minor
- `audio/planet_defense_perimeter_shop_item_skin_kit_event_or_pickup_sting.wav` — sting — cosmic-minor