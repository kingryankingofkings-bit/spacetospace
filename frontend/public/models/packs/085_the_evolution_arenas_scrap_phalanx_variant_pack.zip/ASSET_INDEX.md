# The Evolution Arenas Scrap-Phalanx Variant Pack

Pack number: **085**

## GLB Assets
- `glb_assets/01_landmark_anchor.glb` — Landmark Anchor — static_world_anchor
- `glb_assets/02_local_prop_cluster.glb` — Local Prop Cluster — static_prop_or_debris
- `glb_assets/03_creature_or_npc_variant.glb` — Creature Or Npc Variant — creature_variant_base
- `glb_assets/04_quest_or_system_interactable.glb` — Quest Or System Interactable — quest_or_system_interactable
- `glb_assets/05_water_star_sky_or_liquid_asset.glb` — Water Star Sky Or Liquid Asset — environment_surface_or_sky_proxy

## Textures
- `textures/01_the_evolution_arenas_scrap_phalanx_variant_pack_albedo.png` — local surface albedo
- `textures/02_the_evolution_arenas_scrap_phalanx_variant_pack_normal_proxy.png` — placeholder normal-map proxy
- `textures/03_the_evolution_arenas_scrap_phalanx_variant_pack_trim.png` — architecture/prop trim sheet
- `textures/04_the_evolution_arenas_scrap_phalanx_variant_pack_emission.png` — glowing signage, runes, creatures, UI, and VFX
- `textures/05_the_evolution_arenas_scrap_phalanx_variant_pack_decal.png` — floor/wall decals and quest markers
- `textures/06_the_evolution_arenas_scrap_phalanx_variant_pack_water.png` — water/liquid/caustic surface
- `textures/07_the_evolution_arenas_scrap_phalanx_variant_pack_starfield.png` — skybox/starfield/cosmic overlay
- `textures/08_the_evolution_arenas_scrap_phalanx_variant_pack_surface.png` — secondary local surface variation

## Audio
- `audio/the_evolution_arenas_scrap_phalanx_variant_pack_music_loop.wav` — music — organic
- `audio/the_evolution_arenas_scrap_phalanx_variant_pack_ambience_loop.wav` — ambience — organic
- `audio/the_evolution_arenas_scrap_phalanx_variant_pack_event_or_pickup_sting.wav` — sting — organic