# Planet Defense Perimeter World Detail Kit

Pack number: **024**

## GLB Assets
- `glb_assets/01_landmark_anchor.glb` — Landmark Anchor — static_world_anchor
- `glb_assets/02_local_prop_cluster.glb` — Local Prop Cluster — static_prop_or_debris
- `glb_assets/03_creature_or_npc_variant.glb` — Creature Or Npc Variant — creature_variant_base
- `glb_assets/04_quest_or_system_interactable.glb` — Quest Or System Interactable — quest_or_system_interactable
- `glb_assets/05_water_star_sky_or_liquid_asset.glb` — Water Star Sky Or Liquid Asset — environment_surface_or_sky_proxy

## Textures
- `textures/01_planet_defense_perimeter_world_detail_kit_albedo.png` — local surface albedo
- `textures/02_planet_defense_perimeter_world_detail_kit_normal_proxy.png` — placeholder normal-map proxy
- `textures/03_planet_defense_perimeter_world_detail_kit_trim.png` — architecture/prop trim sheet
- `textures/04_planet_defense_perimeter_world_detail_kit_emission.png` — glowing signage, runes, creatures, UI, and VFX
- `textures/05_planet_defense_perimeter_world_detail_kit_decal.png` — floor/wall decals and quest markers
- `textures/06_planet_defense_perimeter_world_detail_kit_water.png` — water/liquid/caustic surface
- `textures/07_planet_defense_perimeter_world_detail_kit_starfield.png` — skybox/starfield/cosmic overlay
- `textures/08_planet_defense_perimeter_world_detail_kit_surface.png` — secondary local surface variation

## Audio
- `audio/planet_defense_perimeter_world_detail_kit_music_loop.wav` — music — cosmic-minor
- `audio/planet_defense_perimeter_world_detail_kit_ambience_loop.wav` — ambience — cosmic-minor
- `audio/planet_defense_perimeter_world_detail_kit_event_or_pickup_sting.wav` — sting — cosmic-minor